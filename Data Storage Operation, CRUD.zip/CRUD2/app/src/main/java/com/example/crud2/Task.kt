package com.example.crud2

data class Task(
    val id:String? = null,
    val title:String? = null,
    val description:String? = null,
)
