package com.example.crud2


import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.crud2.databinding.ActivitySignupBinding
import com.google.firebase.auth.FirebaseAuth

class Signup : AppCompatActivity() {

    // initializing view binding object for Signup Activity
    private lateinit var binding: ActivitySignupBinding
    // initializing firebase authentication
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)

        // creating an instance of firebase auth
        firebaseAuth = FirebaseAuth.getInstance()

        // navigates to Login screen when clicked on "Already registered" textview
        binding.textView.setOnClickListener{
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
        }

        // when clicked on "Sign up" button
        binding.button.setOnClickListener {
            val email = binding.emailEt.text.toString() //extracting text from email edit_textview
            val password = binding.passET.text.toString() //extracting text from password edit_textview

            /*-------------Logic------------------
            if (fields are empty) {
                show Toast
            } else {
                validate email&password and create user
                navigate to LoginActivity on completion of operation
            }
            ------------------------------------- */
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter email or password", Toast.LENGTH_SHORT).show();
            } else {
                // using firebase method "createUserWithEmailAndPassword"
                // to validate email&password and create user
                firebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener {
                    /*-------------Logic------------------
                  if (successful) {
                      navigate to LoginActivity
                  } else {
                       show Toast
                  }
                  ------------------------------------- */
                    if (it.isSuccessful) {
                        val intent = Intent(this, Login::class.java)
                        startActivity(intent)
                    } else {
                        Toast.makeText(this, it.exception.toString(), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}