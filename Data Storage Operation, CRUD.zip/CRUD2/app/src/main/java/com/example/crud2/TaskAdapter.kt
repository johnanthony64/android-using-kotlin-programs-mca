package com.example.crud2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TaskAdapter: RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {
    private var taskList = mutableListOf<Task>()
    private var onClickView: ((Task)-> Unit)? = null
    private var onClickDelete: ((Task)-> Unit)? = null



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val context = parent.context
        val inflater = LayoutInflater.from(context)
        val itemView = inflater.inflate(R.layout.task_item_viewholder,parent, false)
        return TaskViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return taskList.size
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = taskList[position]
        holder.setItem(task)
        holder.setOnClickView {
            onClickView?.invoke(it)
        }
        holder.setOnClickDelete {
            onClickDelete?.invoke(it)
        }
    }

    fun setItems(list: MutableList<Task>) {
        this.taskList = list
        notifyDataSetChanged()
    }

    fun setOnClickView(callback: (Task)-> Unit) {
        this.onClickView= callback
    }

    fun setOnClickDelete(callback: (Task) -> Unit) {
        this.onClickDelete = callback
    }

    class TaskViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        private var tvTitle: TextView? = null
        private var tvDescription: TextView? = null
        private var actionView: ImageView? = null
        private var actionDelete: ImageView? = null

        private var onClickView: ((Task) -> Unit)? = null
        private var onClickDelete: ((Task)-> Unit)? = null

        fun setItem(data: Task) {
            tvTitle = itemView.findViewById(R.id.tv_title)
            tvDescription = itemView.findViewById(R.id.tv_description)
            actionView = itemView.findViewById(R.id.ic_view)
            actionDelete = itemView.findViewById(R.id.ic_delete)

            tvTitle?.text = data.title
            tvDescription?.text = data.description


            actionView?.setOnClickListener {
                onClickView?.invoke(data)
            }

            actionDelete?.setOnClickListener {
                onClickDelete?.invoke(data)
            }


        }

        fun setOnClickView(callback: (Task)-> Unit) {
            this.onClickView = callback
        }

        fun setOnClickDelete(callback: (Task)-> Unit) {
            this.onClickDelete = callback
        }

    }
}