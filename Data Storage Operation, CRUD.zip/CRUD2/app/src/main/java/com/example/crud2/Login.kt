package com.example.crud2

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.crud2.databinding.ActivityLoginBinding
import com.google.firebase.auth.FirebaseAuth

class Login : AppCompatActivity() {

    // initializing view binding object for Login Activity
    private lateinit var binding: ActivityLoginBinding
    // initializing firebase authentication
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // creating an instance of firebase auth
        firebaseAuth = FirebaseAuth.getInstance()

        // navigates to Signup screen when clicked on "Already registered" textview
        binding.textView.setOnClickListener {
            val intent = Intent(this, Signup::class.java)
            startActivity(intent)
        }

        // when clicked on "login button"
        binding.loginButton.setOnClickListener {
            val email = binding.emailEt.text.toString() //extracting text from email edit_textview
            val password = binding.passET.text.toString() //extracting text from password edit_textview

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter email or password", Toast.LENGTH_SHORT).show();
            } else {
                firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener {
                    if (it.isSuccessful) {
                        val intent = Intent(this, MainActivity::class.java)
                        startActivity(intent)
                    } else {
                        Toast.makeText(this, it.exception.toString(), Toast.LENGTH_SHORT).show()
                    }
                }
            }

        }

    }

    override fun onStart() {
        super.onStart()
        // if users has already logged in, navigate to MainActivity during onStart phase of an Activity
        if (firebaseAuth.currentUser != null) {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish() // finish the current activity to prevent the user from coming back to it using the back button
        }
    }
}
