package com.example.crud2

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.crud2.databinding.ActivityMainBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {

    // initializing view binding object for Login Activity
    private lateinit var binding: ActivityMainBinding
    // initializing firebase authentication
    private lateinit var firebaseAuth: FirebaseAuth
    // initializing firebase databases
    private lateinit var firebaseDatabase: FirebaseDatabase
    // initializing database reference
    private lateinit var databaseReference: DatabaseReference

    // variable to store selected task id
    private var selectedId: String? = null
    // mutable list to store all tasks
    private var tasks = mutableListOf<Task>()
    // initializing TaskAdapter object
    private var adapter: TaskAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // creating an instance of firebase auth
        firebaseAuth = FirebaseAuth.getInstance()
        // creating an instance of firebase database
        firebaseDatabase = FirebaseDatabase.getInstance()
        // creating an task collection in firebase database
        databaseReference = firebaseDatabase.getReference("tasks")

        // retrieving current logged in user email id
        val userEmailDB = firebaseAuth.currentUser?.email.toString()
        val userEmail = binding.emailTextView
        // showing email id in textview
        userEmail.text = userEmailDB

        // user-define method to initialize recycler view adapter
        initRecyclerView()

        // when clicked on logout button
        binding.logoutButton.setOnClickListener {
            // using firebase method "signOut"
            // to end session
            firebaseAuth.signOut();
            // navigate to Login Screen
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
            finish()
        }

        // when clicked on save button
        binding.saveButton.setOnClickListener {
            saveData()
        }

        // when clicked on update button
        binding.updateButton.setOnClickListener {
            updateData()
        }

        // displaying available data
        getData()
    }

    // method to update data
    private fun updateData() {
        val title = binding.titleEditTextview.text.toString() //extracting text from title edit_textview
        val description = binding.descriptionEditTextview.text.toString() //extracting text from description edit_textview
        val task = Task(title=title, description = description) // creating new com.example.crud2.Task object

        databaseReference.child(selectedId.toString()).setValue(task) // updating selected task values
    }

    private fun getData() {
        databaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // clearing all previous tasks to avoid redundancy
                tasks.clear()
                // loop to add all tasks in mutableList
                for (ds in snapshot.children) {
                    val id = ds.key
                    val title = ds.child("title").value.toString()
                    val description = ds.child("description").value.toString()
                    val newTask = Task(id, title, description)
                    tasks.add(newTask)
                }
                adapter?.setItems(tasks)
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        })
    }

    // method to initialize recycler view adapter
    private fun initRecyclerView() {
        adapter = TaskAdapter()
        binding.apply {
            recyclerView.layoutManager = LinearLayoutManager(this@MainActivity)
            recyclerView.adapter = adapter
        }

        adapter?.setOnClickView {
            binding.titleEditTextview.setText(it.title.toString())
            binding.descriptionEditTextview.setText(it.description.toString())
            selectedId = it.id
        }

        adapter?.setOnClickDelete {
            selectedId = it.id
            databaseReference.child(selectedId.orEmpty()).removeValue()
        }
    }

    //method to save data
    private fun saveData() {
        val title = binding.titleEditTextview.text.toString() //extracting text from title edit_textview
        val description = binding.descriptionEditTextview.text.toString() //extracting text from description edit_textview
        val task = Task(title=title, description = description) // creating new com.example.crud2.Task object

        databaseReference.child(getRandomString(5)).setValue(task) // saving created task in database
    }

    //method to generate random strings for task id
    fun getRandomString(length: Int) : String {
        val allowedChars = ('A'..'Z') + ('a'..'z') + ('0'..'9')
        return (1..length)
            .map { allowedChars.random() }
            .joinToString("")
    }
}