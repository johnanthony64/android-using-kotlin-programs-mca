package com.example.foodex

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class DonationActivity : AppCompatActivity() {
    private lateinit var donationAmountEditText: EditText
    private lateinit var donateButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_donation)

        donationAmountEditText = findViewById(R.id.editTextDonationAmount)
        donateButton = findViewById(R.id.btnDonate)

        donateButton.setOnClickListener {
            val donationAmountText = donationAmountEditText.text.toString()

            if (donationAmountText.isBlank()) {
                // Show error if donation amount is empty
                showAlertDialog("Error", "Please enter donation amount.")
            } else {
                val donationAmount = donationAmountText.toDouble()

                if (donationAmount <= 0) {
                    // Show error if donation amount is non-positive
                    showAlertDialog("Error", "Invalid donation amount.")
                } else {
                    // Display AlertDialog to confirm donation
                    val confirmMessage = "Are you sure you want to donate ₹$donationAmount?"
                    showConfirmDialog(confirmMessage, donationAmount)
                }
            }
        }
    }

    private fun showAlertDialog(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showConfirmDialog(message: String, donationAmount: Double) {
        AlertDialog.Builder(this)
            .setTitle("Confirm Donation")
            .setMessage(message)
            .setPositiveButton("Confirm") { dialog, _ ->
                // Show thank you message
                showAlertDialog("Thank You", "Thank you for your donation!")

                // Navigate to MainActivity
                startActivity(Intent(this, MainActivity::class.java))
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
