package com.example.foodex

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class PickupDeliveryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pickup_delivery)

        val btnConfirm = findViewById<Button>(R.id.btnConfirm)
        val radioGroupOption = findViewById<RadioGroup>(R.id.radioGroupOption)
        val radioButtonPickup = findViewById<RadioButton>(R.id.radioButtonPickup)
        val radioButtonDelivery = findViewById<RadioButton>(R.id.radioButtonDelivery)

        btnConfirm.setOnClickListener {
            val selectedOptionId = radioGroupOption.checkedRadioButtonId

            if (selectedOptionId == -1) {
                // Show error message if no option is selected
                Toast.makeText(this, "Please select an option", Toast.LENGTH_SHORT).show()
            } else {
                // Get the selected option text
                val selectedOption = findViewById<RadioButton>(selectedOptionId).text.toString()

                // Display a Toast for confirmation
                val confirmationMessage = "You have confirmed $selectedOption"
                Toast.makeText(this, confirmationMessage, Toast.LENGTH_SHORT).show()

                // Proceed to MainActivity
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
        }
    }
}
