package com.example.foodex

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class RequestActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_request)

        val btnSubmitRequest = findViewById<Button>(R.id.btnSubmitRequest)
        val editTextFoodDescription = findViewById<TextInputEditText>(R.id.editTextFoodDescription)
        val editTextQuantity = findViewById<TextInputEditText>(R.id.editTextQuantity)

        btnSubmitRequest.setOnClickListener {
            val foodDescription = editTextFoodDescription.text.toString()
            val quantity = editTextQuantity.text.toString()

            if (foodDescription.isBlank() || quantity.isBlank()) {
                // Show error message if any field is empty
                AlertDialog.Builder(this)
                    .setTitle("Error")
                    .setMessage("All fields are required.")
                    .setPositiveButton("OK", null)
                    .show()
            } else {
                // Display a Toast for thanking the user and navigate to main activity
                Toast.makeText(this, "Your request has been submitted.", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
        }
    }
}
