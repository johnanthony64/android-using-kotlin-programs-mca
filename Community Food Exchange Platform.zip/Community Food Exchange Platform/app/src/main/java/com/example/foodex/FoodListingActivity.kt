package com.example.foodex

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class FoodListingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_food_listing)

        val btnPostListing = findViewById<Button>(R.id.btnPostListing)
        val editTextFoodDescription = findViewById<TextInputEditText>(R.id.editTextFoodDescription)
        val editTextQuantity = findViewById<TextInputEditText>(R.id.editTextQuantity)
        val editTextExpirationDate = findViewById<TextInputEditText>(R.id.editTextExpirationDate)

        btnPostListing.setOnClickListener {
            val foodDescription = editTextFoodDescription.text.toString()
            val quantity = editTextQuantity.text.toString()
            val expirationDate = editTextExpirationDate.text.toString()

            if (foodDescription.isBlank() || quantity.isBlank() || expirationDate.isBlank()) {
                // Show error message if any field is empty
                AlertDialog.Builder(this)
                    .setTitle("Error")
                    .setMessage("All fields are required.")
                    .setPositiveButton("OK", null)
                    .show()
            } else {
                // Display an alert dialog for confirmation
                val alertDialogBuilder = AlertDialog.Builder(this)
                alertDialogBuilder.setTitle("Post Listing")
                alertDialogBuilder.setMessage("Are you sure you want to post this listing?")
                alertDialogBuilder.setPositiveButton("Yes") { dialogInterface: DialogInterface, _: Int ->
                    // Show a Toast for thanking the user
                    Toast.makeText(this, "Thank you for posting the listing!", Toast.LENGTH_SHORT).show()

                    // Navigate to main activity
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    dialogInterface.dismiss()
                }
                alertDialogBuilder.setNegativeButton("No") { dialogInterface: DialogInterface, _: Int ->
                    dialogInterface.dismiss()
                }
                alertDialogBuilder.show()
            }
        }
    }
}
