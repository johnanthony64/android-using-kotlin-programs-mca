package com.example.foodex

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Set click listeners for each button
        val buttonIds = listOf(R.id.btnPostFoodListings, R.id.btnManageRequests, R.id.btnArrangePickupDelivery, R.id.btnIntegrateCommunityResources, R.id.btnHandleDonations)

        for (buttonId in buttonIds) {
            findViewById<Button>(buttonId).setOnClickListener {
                val intent = when (buttonId) {
                    R.id.btnPostFoodListings -> Intent(this, FoodListingActivity::class.java)
                    R.id.btnManageRequests -> Intent(this, RequestActivity::class.java)
                    R.id.btnArrangePickupDelivery -> Intent(this, PickupDeliveryActivity::class.java)
                    R.id.btnIntegrateCommunityResources -> Intent(this, CommunityKitchenActivity::class.java)
                    R.id.btnHandleDonations -> Intent(this, DonationActivity::class.java)
                    else -> throw IllegalArgumentException("Unknown button ID: $buttonId")
                }
                startActivity(intent)
            }
        }
    }
}
