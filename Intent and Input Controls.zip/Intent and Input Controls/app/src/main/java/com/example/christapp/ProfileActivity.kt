package com.example.christapp

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class ProfileActivity : AppCompatActivity() {
    private lateinit var Button1: Button
    private lateinit var Button2: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        Button1 = findViewById(R.id.Button1)
        Button2 = findViewById(R.id.Button2)

        Button1.setOnClickListener {
            Toast.makeText(this, "Opening Instagram", Toast.LENGTH_SHORT).show()
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com"))
            startActivity(intent)
        }

        Button2.setOnClickListener {
            Toast.makeText(this, "Opening LinkedIn", Toast.LENGTH_SHORT).show()
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.linkedin.com"))
            startActivity(intent)
        }
    }
}
