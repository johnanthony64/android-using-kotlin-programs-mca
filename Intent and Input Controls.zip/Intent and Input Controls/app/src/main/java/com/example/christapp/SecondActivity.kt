package com.example.christapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val profileButton = findViewById<View>(R.id.profileButton)
        profileButton.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            intent.putExtra("name", "Your Name")
            intent.putExtra("rollNumber", "Your Roll Number")
            intent.putExtra("className", "Your Class")
            startActivity(intent)
        }

        val imagesButton = findViewById<View>(R.id.imagesButton)
        imagesButton.setOnClickListener {
            val intent = Intent(this, CollegeImagesActivity::class.java)
            startActivity(intent)
        }

        val formsButton = findViewById<View>(R.id.new_activity_button)
        formsButton.setOnClickListener {
            val intent = Intent(this, FormsActivity::class.java)
            startActivity(intent)
        }
    }
}
